'use strict';

require('dotenv').config();
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const http = require('http');
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const { Server } = require('socket.io');
const { Pool } = require('pg');
const PgSession = require('connect-pg-simple')(session);

const PORT = Number(process.env.PORT || 3000);
const NODE_ENV = process.env.NODE_ENV || 'development';
const IS_PRODUCTION = NODE_ENV === 'production';
const SESSION_SECRET = process.env.SESSION_SECRET || 'dev-only-change-this-secret';
const DATABASE_URL = process.env.DATABASE_URL || '';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'store.json');
const MAX_SNAPSHOT_BYTES = 5 * 1024 * 1024;
const NATIONAL_WORKSPACE = 'sge-uev-nacional';

if (IS_PRODUCTION && SESSION_SECRET === 'dev-only-change-this-secret') {
  console.warn('[SGE] SESSION_SECRET no esta configurado. Definelo antes de usar produccion.');
}

const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '6mb' }));
app.use(express.urlencoded({ extended: false }));

const server = http.createServer(app);
const io = new Server(server, {
  transports: ['websocket', 'polling'],
  maxHttpBufferSize: 6 * 1024 * 1024
});

let pool = null;
let sessionMiddleware = null;
let fileState = { users: [], workspaces: {} };
let writeChain = Promise.resolve();
const workspaceLocks = new Map();
const presence = new Map();

const EMPTY_DB = {
  users: [], currentUser: null,
  config: {
    nombre: 'UNIDAD EDUCATIVA VALDIVIA', distrito: 'DISTRITO VALDIVIA',
    direccion: 'VIA A LOMA ALTA', telefono: '', email: 'col_valdivia@hotmail.com',
    rector: '', anio: '2026-2027', amie: '24H00154'
  },
  courses: [], subjects: [], students: [], teachers: [], grades: {}, behavior: {},
  finalGrades: {}, attendance: {}, periodos: [], periodoActivo: null
};

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function normalizeUsername(value) {
  return String(value || '').trim().toLowerCase();
}

function safeUser(user) {
  return { id: user.id, username: user.username, name: user.name || user.username };
}

function cleanDb(input) {
  const db = input && typeof input === 'object' ? clone(input) : clone(EMPTY_DB);
  delete db.currentUser;
  delete db._lastSync;
  if (Array.isArray(db.users)) {
    db.users = db.users.map((user) => {
      const safe = { ...user };
      delete safe.password;
      delete safe.passwordHash;
      delete safe.salt;
      return safe;
    });
  }
  return db;
}

function cleanSnapshot(data, estadoInsumos) {
  const clean = {
    data: cleanDb(data),
    estadoInsumos: estadoInsumos && typeof estadoInsumos === 'object' ? clone(estadoInsumos) : { t1: {}, t2: {}, t3: {} }
  };
  if (Buffer.byteLength(JSON.stringify(clean), 'utf8') > MAX_SNAPSHOT_BYTES) {
    throw new Error('El respaldo es demasiado grande. Reduce el contenido antes de sincronizar.');
  }
  return clean;
}

function queueWorkspace(workspaceId, work) {
  const previous = workspaceLocks.get(workspaceId) || Promise.resolve();
  const next = previous.catch(() => {}).then(work);
  workspaceLocks.set(workspaceId, next.finally(() => {
    if (workspaceLocks.get(workspaceId) === next) workspaceLocks.delete(workspaceId);
  }));
  return next;
}

async function loadFileState() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  try {
    fileState = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    if (!fileState || !Array.isArray(fileState.users) || !fileState.workspaces) throw new Error('Formato invalido');
  } catch (_) {
    fileState = { users: [], workspaces: {} };
    await persistFileState();
  }
}

function persistFileState() {
  writeChain = writeChain.then(async () => {
    const temp = DATA_FILE + '.tmp';
    await fs.promises.writeFile(temp, JSON.stringify(fileState, null, 2), 'utf8');
    await fs.promises.rename(temp, DATA_FILE);
  });
  return writeChain;
}

async function initStore() {
  if (!DATABASE_URL) {
    await loadFileState();
    console.warn('[SGE] DATABASE_URL no configurado: usando data/store.json. Sirve para pruebas, no para produccion multiusuario.');
    return;
  }
  pool = new Pool({
    connectionString: DATABASE_URL,
    ssl: process.env.PGSSLMODE === 'disable' ? false : { rejectUnauthorized: false },
    max: 10
  });
  await pool.query(`
    CREATE TABLE IF NOT EXISTS sge_users (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS sge_workspaces (
      id TEXT PRIMARY KEY,
      data JSONB NOT NULL,
      estado_insumos JSONB NOT NULL,
      revision INTEGER NOT NULL DEFAULT 0,
      updated_by TEXT,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
  console.log('[SGE] PostgreSQL conectado.');
}

async function findUser(username) {
  const normalized = normalizeUsername(username);
  if (pool) {
    const result = await pool.query('SELECT id, username, name, password_hash FROM sge_users WHERE username = $1', [normalized]);
    return result.rows[0] || null;
  }
  return fileState.users.find((u) => u.username === normalized) || null;
}

async function createUser(username, password) {
  const normalized = normalizeUsername(username);
  const id = crypto.randomUUID();
  const name = normalized.includes('@') ? normalized.split('@')[0] : normalized;
  const passwordHash = await bcrypt.hash(password, 12);
  if (pool) {
    const result = await pool.query(
      'INSERT INTO sge_users (id, username, name, password_hash) VALUES ($1, $2, $3, $4) RETURNING id, username, name',
      [id, normalized, name, passwordHash]
    );
    return result.rows[0];
  }
  const user = { id, username: normalized, name, password_hash: passwordHash };
  fileState.users.push(user);
  await persistFileState();
  return safeUser(user);
}

async function getWorkspace(workspaceId) {
  if (pool) {
    const result = await pool.query(
      'SELECT id, data, estado_insumos, revision, updated_by, updated_at FROM sge_workspaces WHERE id = $1',
      [workspaceId]
    );
    return result.rows[0] || null;
  }
  return fileState.workspaces[workspaceId] || null;
}

async function saveWorkspace(workspaceId, snapshot, updatedBy) {
  return queueWorkspace(workspaceId, async () => {
    const clean = cleanSnapshot(snapshot.data, snapshot.estadoInsumos);
    const current = await getWorkspace(workspaceId);
    const revision = Number(current?.revision || 0) + 1;
    const updatedAt = new Date().toISOString();
    const record = {
      id: workspaceId,
      data: clean.data,
      estado_insumos: clean.estadoInsumos,
      revision,
      updated_by: updatedBy || 'usuario',
      updated_at: updatedAt
    };
    if (pool) {
      await pool.query(`
        INSERT INTO sge_workspaces (id, data, estado_insumos, revision, updated_by, updated_at)
        VALUES ($1, $2::jsonb, $3::jsonb, $4, $5, $6)
        ON CONFLICT (id) DO UPDATE SET data = EXCLUDED.data, estado_insumos = EXCLUDED.estado_insumos,
          revision = EXCLUDED.revision, updated_by = EXCLUDED.updated_by, updated_at = EXCLUDED.updated_at
      `, [workspaceId, JSON.stringify(record.data), JSON.stringify(record.estado_insumos), revision, record.updated_by, updatedAt]);
    } else {
      fileState.workspaces[workspaceId] = record;
      await persistFileState();
    }
    return record;
  });
}

async function ensureWorkspace(workspaceId, seed) {
  const current = await getWorkspace(workspaceId);
  if (current || !seed) return current;
  return saveWorkspace(workspaceId, seed, seed.updatedBy || 'primer usuario');
}

function userFromRequest(req) {
  return req.session && req.session.user ? req.session.user : null;
}

function requireAuth(req, res, next) {
  if (!userFromRequest(req)) return res.status(401).json({ error: 'Sesion no valida' });
  next();
}

function buildSessionMiddleware() {
  return session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    store: pool ? new PgSession({ pool, createTableIfMissing: true }) : undefined,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      secure: IS_PRODUCTION,
      maxAge: 1000 * 60 * 60 * 12
    }
  });
}
app.use((req, res, next) => {
  if (!sessionMiddleware) return res.status(503).json({ error: 'Servidor iniciando' });
  return sessionMiddleware(req, res, next);
});

app.get('/health', async (_req, res) => {
  let database = 'file';
  if (pool) {
    try { await pool.query('SELECT 1'); database = 'postgres'; } catch (_) { return res.status(503).json({ ok: false, database: 'error' }); }
  }
  res.json({ ok: true, service: 'sge-uev-online', database, workspace: NATIONAL_WORKSPACE, time: new Date().toISOString() });
});

app.post('/api/auth/register', async (req, res) => {
  try {
    const username = normalizeUsername(req.body.username);
    const password = String(req.body.password || '');
    if (!username || username.length < 3) return res.status(400).json({ error: 'Ingrese un usuario valido' });
    if (password.length < 8) return res.status(400).json({ error: 'La contraseña debe tener al menos 8 caracteres' });
    if (await findUser(username)) return res.status(409).json({ error: 'Ese usuario ya esta registrado' });
    const user = await createUser(username, password);
    res.status(201).json({ ok: true, user: safeUser(user) });
  } catch (error) {
    if (error.code === '23505') return res.status(409).json({ error: 'Ese usuario ya esta registrado' });
    console.error('[SGE] register:', error);
    res.status(500).json({ error: 'No se pudo registrar el usuario' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const username = normalizeUsername(req.body.username);
    const password = String(req.body.password || '');
    const user = await findUser(username);
    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: 'Correo o contraseña incorrectos' });
    }
    req.session.user = safeUser(user);
    res.json({ ok: true, user: req.session.user });
  } catch (error) {
    console.error('[SGE] login:', error);
    res.status(500).json({ error: 'No se pudo iniciar sesion' });
  }
});

app.get('/api/auth/me', requireAuth, (req, res) => res.json({ ok: true, user: userFromRequest(req) }));
app.post('/api/auth/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));
app.get(/.*/, (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

io.engine.use((req, res, next) => {
  if (!sessionMiddleware) return next(new Error('Servidor iniciando'));
  return sessionMiddleware(req, res, next);
});
io.use((socket, next) => {
  if (!socket.request.session || !socket.request.session.user) return next(new Error('Sesion no valida'));
  next();
});

function socketUser(socket) {
  return socket.request.session.user;
}

function roomName(id) { return `workspace:${id}`; }
function validWorkspace(id) { return typeof id === 'string' && /^[a-zA-Z0-9_-]{3,80}$/.test(id); }
function listPresence(id) { return Array.from((presence.get(id) || new Map()).values()); }
function broadcastPresence(id) { io.to(roomName(id)).emit('presence:update', listPresence(id)); }

io.on('connection', (socket) => {
  socket.on('workspace:join', async (payload = {}) => {
    try {
      const workspaceId = String(payload.workspaceId || '');
      if (!validWorkspace(workspaceId)) return socket.emit('workspace:error', 'ID de espacio de trabajo no valido');
      if (socket.data.workspaceId) {
        const old = socket.data.workspaceId;
        socket.leave(roomName(old));
        presence.get(old)?.delete(socket.id);
        broadcastPresence(old);
      }
      socket.data.workspaceId = workspaceId;
      socket.join(roomName(workspaceId));
      if (!presence.has(workspaceId)) presence.set(workspaceId, new Map());
      presence.get(workspaceId).set(socket.id, {
        deviceId: String(payload.deviceId || '').slice(0, 120),
        user: socketUser(socket).name || socketUser(socket).username,
        browser: String(payload.browser || 'Navegador').slice(0, 120)
      });
      const existing = await ensureWorkspace(workspaceId, payload.seed);
      const state = existing || await getWorkspace(workspaceId);
      if (state) {
        socket.emit('workspace:state', {
          workspaceId,
          data: state.data,
          estadoInsumos: state.estado_insumos,
          revision: state.revision,
          updatedBy: state.updated_by || 'servidor'
        });
      }
      broadcastPresence(workspaceId);
    } catch (error) {
      console.error('[SGE] workspace join:', error);
      socket.emit('workspace:error', 'No se pudo conectar al espacio de trabajo');
    }
  });

  socket.on('workspace:update', async (payload = {}) => {
    try {
      const workspaceId = socket.data.workspaceId;
      if (!workspaceId || workspaceId !== payload.workspaceId) return socket.emit('workspace:error', 'Espacio de trabajo no conectado');
      const record = await saveWorkspace(workspaceId, payload, socketUser(socket).name || socketUser(socket).username);
      const outgoing = {
        workspaceId,
        data: record.data,
        estadoInsumos: record.estado_insumos,
        revision: record.revision,
        updatedBy: record.updated_by,
        deviceId: String(payload.deviceId || '')
      };
      socket.to(roomName(workspaceId)).emit('workspace:update', outgoing);
      socket.emit('workspace:ack', { revision: record.revision });
    } catch (error) {
      console.error('[SGE] workspace update:', error);
      socket.emit('workspace:error', error.message || 'No se pudo guardar la informacion');
    }
  });

  socket.on('disconnect', () => {
    const workspaceId = socket.data.workspaceId;
    if (!workspaceId) return;
    presence.get(workspaceId)?.delete(socket.id);
    broadcastPresence(workspaceId);
    if (presence.get(workspaceId)?.size === 0) presence.delete(workspaceId);
  });
});

(async () => {
  await initStore();
  sessionMiddleware = buildSessionMiddleware();
  server.listen(PORT, '0.0.0.0', () => console.log(`[SGE] Servidor listo en puerto ${PORT}`));
})().catch((error) => {
  console.error('[SGE] Error fatal al iniciar:', error);
  process.exit(1);
});
