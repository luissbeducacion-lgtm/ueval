# SGE UE Valdivia Online

Paquete desplegable del Sistema de Gestion Educativa de la Unidad Educativa Valdivia.

## Que incluye

- Frontend original en `public/index.html`.
- Backend Node.js + Express.
- Registro, inicio y cierre de sesion con contraseñas cifradas.
- Sesion mediante cookie segura.
- Sincronizacion multiusuario en tiempo real con Socket.io.
- Persistencia en PostgreSQL cuando existe `DATABASE_URL`.
- Fallback local en `data/store.json` para desarrollo solamente.

## Probar en tu computadora

Requiere Node.js 20 o superior.

```bash
npm install
cp .env.example .env
npm start
```

Abre `http://localhost:3000`. Crea el primer usuario desde la pestaña **Registrarse**.

## Publicar en Render

1. Crea un repositorio nuevo en GitHub y sube todos los archivos de esta carpeta.
2. En Render elige **New > Blueprint** y conecta ese repositorio.
3. Render leerá `render.yaml`, creará el servicio web y la base PostgreSQL.
4. Espera el deploy y abre la URL `https://...onrender.com`.
5. Comparte esa URL. Los usuarios podrán registrarse e iniciar sesión desde cualquier navegador.

El servicio usa el espacio compartido `sge-uev-nacional`, así que los usuarios autenticados ven la misma información y los cambios se sincronizan en tiempo real.

## Produccion nacional

El plan gratuito sirve para validar y hacer pilotos, pero Render indica que sus recursos gratuitos no son para aplicaciones criticas. Para operar con datos educativos reales, usa una instancia de produccion, respaldos PostgreSQL, dominio propio HTTPS, cuentas controladas y reglas de permisos por rol. No publiques contraseñas ni abras una base de datos sin autenticacion.

## Variables importantes

- `SESSION_SECRET`: secreto largo y aleatorio para firmar sesiones.
- `DATABASE_URL`: cadena de conexion PostgreSQL. Render la inyecta desde `render.yaml`.
- `NODE_ENV=production`: activa cookies seguras.

## Nota de seguridad

La interfaz actual permite que cualquier usuario se registre. Antes de abrirla a todo el pais conviene restringir el registro a usuarios autorizados y añadir roles, auditoria, copias de seguridad y control de acceso por institucion.
